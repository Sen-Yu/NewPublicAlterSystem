package com.company;


import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import java.io.IOException;
import java.net.*;

import java.util.Vector;

public class Server {
    DatagramSocket datagramSocket;


    public Server(int serverPort) {
        try {
            //저장할 메세지들
            AllMessage allMessage = new AllMessage();
            this.datagramSocket = new DatagramSocket(serverPort);
            Vector<ThreadSender> senders = new Vector<ThreadSender>();

            while (true) {
                byte buffer[] = new byte[512];
                DatagramPacket datagramPacket = new DatagramPacket(buffer, buffer.length);

                //메세지 대기중
                System.out.print("--------------------------------------------------------------------------------");
                System.out.print("CBC ready");
                System.out.println("--------------------------------------------------------------------------------");
                //메세지 받음
                this.datagramSocket.receive(datagramPacket);

                String message = new String(datagramPacket.getData()).trim();
                System.out.println(message);
                InetAddress datagramInetAddress = datagramPacket.getAddress();
                int datagramPort = datagramPacket.getPort();

                //메세지 체크
                String messageType = getMessageType(message);
                System.out.println("messageType:" + messageType);

                    if (messageType.equals("Emergency_Broadcast_Request")) {
                        //파싱
                            //Warning문자 생성
                            Warning warning = new Warning(this.datagramSocket, datagramInetAddress);
                            warning.jsonToWarning(message);
                            int warningClass = warning.classify();
                            warning.setMessageidentifier(warningClass);
                            warning.setSerialNumber(warningClass);
                            warning.setWarningContentMessage(message);
                            //전에 보낸 메세지가 있는지 확인
                            int same = allMessage.findSameCoordinate(warning.getWarningAreaCoordinates());
                            //있는경우 업데이트번호 증가,내용 수정
                            if(same > -1){
                                System.out.println("전에 보낸 메시지의 업데이트버전");
                               // System.out.println(allMessage.getWarning(same).getWarningContentMessage()+"를 "+warning.getContext()+"로 update");
                                 allMessage.getWarning(same).update();
                                 allMessage.getWarning(same).setWarningContentMessage(warning.getContext());
                                 warning = allMessage.getWarning(same);
                                 //기존의 TAI사용
                            }
                            //없는경우 생성
                            else{
                                System.out.println("최초의 메시지이다.");
                                warning.setWarningContentMessage(warning.getContext());
                                int repetition = warning.getRepetitionPeriod();
                                int number = warning.getNumberOfBroadcasts();
                                System.out.println(warning.getContext());
                                //TAI설정하기
                            }
                            //System.out.println("현재warning:"+warning.getContext());
                            int repetition = warning.getRepetitionPeriod();
                            int number = warning.getNumberOfBroadcasts();
                            //TAI설정
                            //현재는 임의로 설정
                            //Warning기록
                            allMessage.getWarningVector().add(warning);

                            //MME로 전송(2차방법)(단일 전송)//
                        /*
                            warning.setSender(this.datagramSocket,warning.WarningToJson().toJSONString().getBytes(), datagramInetAddress, datagramPort,repetition,number);
                            warning.getSender().setBroadPacket(datagramInetAddress,6000);
                            warning.send();
                        */
                            //MME로 전송(3차방법)다중 전송
                            //sned allMME(현재는 MME가 6000,6001,60002로 설정 되있다고 가정)
                        for(int i = 0 ; i < 3 ; i++) {
                            ThreadSender sender = new ThreadSender(this.datagramSocket, warning.WarningToJson().toJSONString().getBytes(), datagramInetAddress, datagramPort, repetition, number);
                            sender.setBroadPacket(datagramInetAddress, 6000+i);
                            warning.addSender(sender);
                        }
                        warning.sends();
                    }

                    else if (messageType.equals("Write_Replace_Warning_Confirm")) {
                        int MessageIdentifier = getMessageIdentifier(message);
                        int SerialNumber = getSerialNumber(message);

                        //검색
                        int num = allMessage.findSameWarning(SerialNumber,MessageIdentifier);
                        System.out.println("num:"+num);
                        //찾음
                        if(num != -1) {
                            Warning warning = allMessage.getWarning(num);
                            //재난 confrim
                            if((SerialNumber & 0b0000111111110000) == 0) {
                                System.out.println("MME에게서 재난정보confirm수신");
                                //단일전송
                                /*
                                warning.getSender().setConfirmPacket(warning.getSerialNumber(), warning.getMessageidentifier(), warning.getWaringAreaCoordinates());
                                //재전송중단
                                warning.confirm();
                                //confirm전송
                                warning.getSender().sendConfirm();
                                //추가정보 문자때문에 바로 삭제 안함(kill받으면 삭제하게 만들예정)
                                //allMessage.deleteWarning(num);
                                 */
                                //다중전송
                                //원래는IP지만 로컬이기때문에 port로 검색함
                                ThreadSender sender = warning.findSender(datagramPort);
                                //정상적인MME로부터의 confirm
                                if(sender != null){
                                    System.out.println("CBE에게 confirm준비중");
                                    //
                                    warning.setConfirmSender(sender);
                                    //
                                    sender.setConfirmPacket(warning.getSerialNumber(), warning.getMessageidentifier(), warning.getWarningAreaCoordinates());
                                    sender.confirm();
                                    //warning내의 sender삭제
                                    warning.removeSender(sender);
                                    //다보냈을경우에만 패킷전송
                                    if(warning.ThreadISNull()) {
                                        warning.sendConfirm();
                                    }
                                }
                            }
                            //쉘터 confirm
                            else{
                                System.out.println("쉘터정보confirm");
                                //단일전송
                                /*
                                //해당 재난문자의 shelter불러옴
                                Shelter shelter = warning.getShelter();
                                //해당 문자와 같은 shelter 재전송 중단
                                shelter.confirm(SerialNumber);
                                warning.getSender().setConfirmPacket(warning.getSerialNumber(), warning.getMessageidentifier(), warning.getWaringAreaCoordinates());
                                warning.getSender().sendConfirm();
                                */
                                //다중전송
                                Shelter shelter = warning.getShelter();
                                shelter.confirm(SerialNumber,datagramPort);
                                ThreadSender sender = shelter.findSender(datagramPort,SerialNumber);
                                //정상적인MME로부터의 confirm
                                if(sender != null){
                                    sender.setConfirmPacket(warning.getSerialNumber(), warning.getMessageidentifier(), warning.getWarningAreaCoordinates());
                                    sender.confirm();
                                    shelter.removeSender(sender);
                                    if(shelter.ThreadISNull()) {
                                        sender.sendConfirm();
                                    }
                                }
                            }
                        }
                    }
                    else if (messageType.equals("Shelter_Broadcast_Request")) {
                        int MessageIdentifier = getMessageIdentifier(message);
                        int SerialNumber = getSerialNumber(message);

                        //검색
                        //confirm인경운 쉘터문자도 확인하는 기능 추가!!!
                        int num = allMessage.findSameWarning(SerialNumber,MessageIdentifier);
                        System.out.println("num:"+num);
                        if(num != -1) {
                            Warning warning = allMessage.getWarning(num);
                            //재난 문자 업데이트
                            warning.update();
                            //이 재난문자의 TAI List를 불러옴
                            warning.getTrackingAreaVector();
                            JSONObject WarningObject = warning.WarningToJson();
                            //System.out.println("쉘터정보 보내는 재난문자 원본:" +  WarningObject);
                            Shelter shelter = warning.getShelter();
                            shelter.ReadShelterText();
                            //구 단위로 패킷생성 및 전송
                            shelter.makePacket(WarningObject);
                            //CBE에게 업데이트 됬다고 알림
                            //confrim을보내고 해당 재난정보의 serialnumber++시킴

                        }


                    }
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

    }

    public String getMessageType(String message){
        try {
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonObject = (JSONObject) jsonParser.parse(message);

            System.out.println("recieve:" + jsonObject.toJSONString());
            return (String) jsonObject.get("messageType");
        }catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public int getMessageIdentifier(String message){
        try {
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonObject = (JSONObject) jsonParser.parse(message);

            return (int)(long) jsonObject.get("messageidentifier");
        }catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }
    public int getSerialNumber(String message){
        try {
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonObject = (JSONObject) jsonParser.parse(message);

            return (int)(long) jsonObject.get("serialNumber");
        }catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static void main(String[] args) throws Exception {


        new Server(5000);
    }
}
