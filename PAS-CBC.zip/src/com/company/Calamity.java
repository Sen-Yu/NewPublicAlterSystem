package com.company;

import java.util.Vector;

public class Calamity {

    //위급 재난
    Vector<String> dnlrmq;
    //긴급 재난
    Vector<String> rlsrmq;
    //안전 안내
    Vector<String> dkswjs;

    //메시지 식별자 선택
    //입력: 보낸 곳,재난이름
    int selectMessageIdentifier(){


        return 0;
    }

    //시리얼 번호 선택
    //입력: 메시지 식별자,추가여부부
    int selectSerialNumber(int messageID, boolean add){
        int GS = 00;
        int MessageCode = 0000000000;
        int UpdateNumber = 00;

        if(messageID == 4372){

        } else{

        }


        return 0;
    }





}
