package com.company;

import java.util.HashMap;
import java.util.Vector;

public class WriteWarningRequest {

    Vector<Warning> warnings;
    int messageIdentifier;
    int serialNumber;
    int warningContentMessage;
    int dataCodingScheme;
    int repetitionPeriod;
    int noOfBroadcastsRequested;

    public void init(){

    }



}
