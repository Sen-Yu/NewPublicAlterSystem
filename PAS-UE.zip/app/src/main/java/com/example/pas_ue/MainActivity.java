package com.example.pas_ue;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import java.io.Serializable;
import java.util.Observable;
import java.util.Vector;

public class MainActivity extends Activity {

    //서버주서
    public static final String sIP = "192.168.25.20";
    public TCPServer tcp;
    public MessageList messageList;
    // LocationManager 객체를 얻어온다

    public MessageObservable observable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);

        findViewById(R.id.button_위급).setOnClickListener(mClickListener);
        findViewById(R.id.button_긴급).setOnClickListener(mClickListener);
        findViewById(R.id.button_안전).setOnClickListener(mClickListener);
        findViewById(R.id.button_setting).setOnClickListener(mClickListener);


        //메세지 리스트 생성
        this.messageList = new MessageList();
        //메세지정보를 저장한 내용들이 있으면 불러오기


        //옵저버 추가
        this.observable = this.messageList.getMessageObservable();

        //tcp소켓 생성(수신 기다리는중)
        this.tcp = new TCPServer(this.messageList);
        this.tcp.execute();
    }

    //<!-- 버튼리스너 -->
    Button.OnClickListener mClickListener = new Button.OnClickListener() {

        public void onClick(View v) {
            Intent intent;
            switch (v.getId()) {

                case R.id.button_위급:
                    Log.i("class0_button","click");
                    try {
                        //(현재 액티비티 , 전환액티비비티 클래스)
                        intent = new Intent(MainActivity.this, MessageListActivity.class);
                        //(문자클래스: 우측상단)
                        intent.putExtra("class","위급재난문자");
                        snedMessageContext(0,intent);
                        //(액티비티전환)
                        startActivityForResult(intent,1);
                    } catch (Exception e) {
                        Log.i("class0_button",e.toString());
                    }
                    break;

                case R.id.button_긴급:
                    Log.i("class1_button","click");
                    try {
                        //(현재 액티비티 , 전환액티비비티 클래스)
                        intent = new Intent(MainActivity.this, MessageListActivity.class);
                        //(문자클래스: 우측상단)
                        intent.putExtra("class","긴급재난문자");
                        snedMessageContext(1,intent);
                        //(액티비티전환)
                        startActivityForResult(intent,1);
                    } catch (Exception e) {
                        Log.i("class1_button",e.toString());
                    }
                    break;

                case R.id.button_안전:
                    Log.i("class2_button","click");
                    try {
                        //(현재 액티비티 , 전환액티비비티 클래스)
                        intent = new Intent(MainActivity.this, MessageListActivity.class);
                        //(문자클래스: 우측상단)
                        intent.putExtra("class","안전안내문자");
                        snedMessageContext(2,intent);
                        //(액티비티전환)
                        startActivityForResult(intent,1);
                    } catch (Exception e) {
                        Log.i("class2_button",e.toString());
                    }
                    break;

                case R.id.button_setting:
                    Log.i("setting_button","click");
                    try {

                    } catch (Exception e) {
                        Log.i("class0_button",e.toString());
                    }
                    break;


            }
        }
    };

    //벡터내의 메시지내용들은 해당 인텐트에게 전송
    public void snedMessageContext(int num,Intent intent){
        Log.d("Tag", "snedMessageContext");
        Vector<Message> vector = this.messageList.getClassVector(num);
        //클래스번호,클래스벡터,벡터 사이즈 ,메세지 옵저버
        intent.putExtra("classNum",num);
        intent.putExtra("size",vector.size());
        //벡터는 어레이리스트로 타입변환 되서 반영 하기 힘듬
        //intent.putExtra("vector",vector);
        //현재 벡터가 가진 정보를 보냄
        for(int i = 0 ; i < vector.size() ; i++){
            intent.putExtra("msg"+i,vector.get(i).getCB_Data());
            Log.d("Tag", "msg"+i);
        }
        intent.putExtra("observable", this.messageList.getMessageObservable());


    }

    //메세시페이지중에 메세지 받을시 데이터 넘겨줌
    public void updateMessageContext(int num,Intent intent){
        Log.d("Tag", "updateMessageContext");
        Vector<Message> vector = this.messageList.getClassVector(num);
        intent.putExtra("size",vector.size());
        for(int i = 0 ; i < vector.size() ; i++){
            intent.putExtra("msg"+i,vector.get(i).getCB_Data());
            Log.d("Tag", "msg"+i);
        }

    }


}
