package com.example.pas_ue;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;


public class MessageListActivity extends Activity implements Observer {
    //5월5일

    private ListView listView;
    private ScrollView scrollView;
    private MessageAdapter adapter;
    private TextView messageClassText;

    private int classNum;
    private int updateVectorSize;
    private int inputVectorSize;
    private ArrayList<Message> vector;
    //private MessageObserver messageObserver;

    Observable observable;
    Message msg;
    int observableClassNum;
    boolean isUpdate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_messagelist);
        findViewById(R.id.button_back).setOnClickListener(mClickListener);
        this.messageClassText = findViewById(R.id.text_messageClass);
        this.scrollView = (ScrollView) findViewById(R.id.message_scrollview);
        this.adapter = new MessageAdapter();
        this.listView = (ListView) findViewById(R.id.messagelist_view);
        this.listView.setAdapter(this.adapter);

        //인텐트 데이터 수신
        Intent intent = getIntent();
        this.messageClassText.setText((String) intent.getStringExtra("class"));
        this.classNum = (int)intent.getIntExtra("classNum",-1);
        this.inputVectorSize = (int)intent.getIntExtra("size",-1);
        //벡터는 어레이리스트로 타입변환 되서 반영 하기 힘듬
        //this.vector = (Vector<Message>) intent.getSerializableExtra("vector");
        this.observable = (Observable) intent.getSerializableExtra("observable");
        this.observable.addObserver(this);
        ((MessageObservable)this.observable).getObservers().add(this);

        if(this.observable == null){
            Log.d("MessageListActivity", "this.observable is nul!!!");
        }
        else{
            Log.d("MessageListActivity", "this.observable is not nul!!!");
            Log.d("MessageListActivity", "this.observer'number:"+((MessageObservable)this.observable).getlistSize());

        }
        Log.d("MessageListActivity", "get data size:"+String.valueOf(this.inputVectorSize));

        int i;
        String msg;

        if(this.inputVectorSize != -1) {
            for (i = 0; i < this.inputVectorSize; i++) {
                msg = (String) intent.getSerializableExtra("msg" + i);
                this.adapter.addItem(msg);
                this.adapter.notifyDataSetChanged();
            }
        }
        /*새메시지 받기전가지 반복문 반복*/
        /*
        while(true){
            //새메시지 받음으로서 업데이트(새메시지가 추가된 벡터의 클래스번호 받음)
            if(this.messageObserver.getIsUpdate() &&this.messageObserver.getClassNum() == this.classNum) {
                msg = this.messageObserver.getMsg().getCB_Data();
                adapter.addItem(msg);
                adapter.notifyDataSetChanged();

            }
        }
        */
    }

    /*  버튼리스너 */
    Button.OnClickListener mClickListener = new Button.OnClickListener() {
        public void onClick(View v) {
            Intent intent;
            switch (v.getId()) {
                case R.id.button_back:
                    Log.i("back_button","click");
                    finish();
            }
        }};

    //이게 호출안되고있다 ㄷㄷㄷ

    @Override
    public void update(Observable observable, Object o) {
        Log.d("new recv","observer call update");
        if(observable instanceof  MessageObservable){
            Log.d("Observer","get update1 success");
            MessageObservable messageObservable = (MessageObservable) observable;
            this.msg = messageObservable.getMessage();
            this.observableClassNum = messageObservable.getClassNum();
            addItem();
        }

    }

    public void update(Message message, int observableClassNum) {
        Log.d("Observer","get update2 success");
            this.msg = message;
            this.observableClassNum = observableClassNum;
            this.isUpdate = true;
            addItem();
    }
    public void addItem(){
        if(this.classNum == this.observableClassNum) {
            Log.d("new recv", "addItem");
            String context = this.msg.getCB_Data();
            this.adapter.addItem(context);
            this.adapter.notifyDataSetChanged();
        }
    }


}
