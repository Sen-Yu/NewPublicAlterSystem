package com.example.pas_ue;

import android.util.Log;

import java.io.Serializable;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

public class MessageObserver implements Observer, Serializable {

    Observable observable;
    Message msg;
    int classNum;
    boolean isUpdate;

    public MessageObserver(Observable observable){
        this.observable = observable;
        this.isUpdate = false;
        observable.addObserver(this);

    }
    @Override
    public void update(Observable observable, Object o) {
        Log.d("MessageObserver","get update");
        if(observable instanceof  MessageObservable){
            MessageObservable messageObservable = (MessageObservable) observable;
            this.msg = messageObservable.getMessage();
            this.classNum = messageObservable.getClassNum();
            this.isUpdate = true;
        }
        else{
            this.isUpdate = false;
        }
    }

    public Message getMsg(){
        return this.msg;
    }
    public int getClassNum(){
        return this.classNum;
    }

    public Boolean getIsUpdate(){
        return this.isUpdate;
    }
}
