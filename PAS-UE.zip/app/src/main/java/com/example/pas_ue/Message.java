package com.example.pas_ue;

import android.util.Log;

import java.io.Serializable;
import java.util.Observable;
import java.util.Vector;

public class Message extends Observable implements Serializable {

    int messageidentifier;
    //int serialNumber;
    SerialNumber serialNumber;
    String CB_Data;//Message Content
    int Data_Coding_scheme;
    int Warning_Area_Coordinates;

    //쉘터정보 문자인경우 쉘터 정보 지속적으로 추가
    ShelterList shelterList;

    public Message(){

    }

    public Message(int messageidentifier,int serialNumber,String CB_Data,int Data_Coding_scheme){
        this.messageidentifier = messageidentifier;
        this.serialNumber = new SerialNumber(serialNumber);
        this.CB_Data =CB_Data;
        this.Data_Coding_scheme = Data_Coding_scheme;

    }

    public Message(int messageidentifier,int serialNumber,String CB_Data,int Data_Coding_scheme,int Warning_Area_Coordinates){
        this.messageidentifier = messageidentifier;
        this.serialNumber = new SerialNumber(serialNumber);
        this.CB_Data =CB_Data;
        this.Data_Coding_scheme = Data_Coding_scheme;
        this.Warning_Area_Coordinates = Warning_Area_Coordinates;
    }

    //해당메세지가 쉘터인지 판별
    public Boolean hasShelterInfo(){
        if(this.shelterList == null){
            return true;
        }
        return false;
    }

    public void createShelterInfo(){
        this.shelterList = new ShelterList();
    }

    //쉘터정보추가
    public void addShelter(Message msg, int mod){
        //쉘터번호 추가
        this.shelterList.addNumber(mod);

        //쉘터 정보 추가 & 선별작업
        this.shelterList.extractJSON(msg.CB_Data);

    }

    public Boolean is_DuplicateShelter(int mod){
        Vector<Integer>ShelterNumbers = this.shelterList.getShelterNumbers();
        for(int i = 0 ; i < ShelterNumbers.size() ; i++) {
            if (ShelterNumbers.get(i) == mod) {
                return true;
            }
        }
        return false;
    }

    //중복문자인지 확인(중복은 참 중복아니면 거짓)
    public int check_duplicate(Message msg){
        String Tag = "check_duplicate";

        Log.d(Tag,"messageIdentifier"+this.messageidentifier+ "="+msg.getMessageidentifier());
        Log.d(Tag,"serialNumber"+this.getPureSerialNumber() + "="+msg.getPureSerialNumber());
        //같은 종류의 문자
        if(this.messageidentifier == msg.getMessageidentifier()){

            //중복문자 수신

            if(this.getPureSerialNumber() == msg.getPureSerialNumber()){
                return 0;
            }
            //업데이트 번호 다름
            return 1;
        }
        //새로운 문자 아님
        else{
            return 2;
        }
    }

    //UE가 해당범위 안에 들어 가있는지 판단
    public void check_Coordinates(){

    }

    public void printContext(){
        Log.d("messageContext",this.CB_Data);
    }

    public int getMessageidentifier() {
        return this.messageidentifier;
    }

    public SerialNumber getSerialNumber() {
        return this.serialNumber;
    }

    public int getPureSerialNumber() {
        return this.serialNumber.getSerialNumber();
    }

    public int getWarning_Area_Coordinates() {
        return this.Warning_Area_Coordinates;
    }

    public String getCB_Data() {
        return this.CB_Data;
    }

    public int getData_Coding_scheme() {
        return this.Data_Coding_scheme;
    }

    public void updateSerialNumber(SerialNumber serialNumber){
        this.serialNumber = serialNumber;
    }

    public ShelterList getShelterList() {
        return this.shelterList;
    }
}

