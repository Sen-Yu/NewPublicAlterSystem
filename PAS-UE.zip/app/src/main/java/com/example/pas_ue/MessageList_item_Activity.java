package com.example.pas_ue;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MessageList_item_Activity{

    private String messageText;

    public String getMessageText() {
        return this.messageText;
    }
    public void setmessageText(String messageText){
        this.messageText = messageText;
    }
}
