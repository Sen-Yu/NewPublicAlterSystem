package com.example.pas_ue;

import java.io.Serializable;

public class SerialNumber implements Serializable {
    //octet1    octet2
    //76543210 76543210
    //00000000 00000000
    int serialNumber;

    int GS;
    int EmergencyUserAlert;
    int Popup;
    int InformationPage;
    int updateNumber;


    public SerialNumber(int serialNumber){
        this.serialNumber = serialNumber;
        this.GS =                   serialNumber | 0b1100000000000000;
        this.EmergencyUserAlert =   serialNumber | 0b0010000000000000;
        this.Popup =                serialNumber | 0b0001000000000000;
        this.InformationPage =      serialNumber | 0b0000111111110000;
        this.updateNumber =         serialNumber | 0b0000000000001111;
    }



    public void decodingSerialNumber(){
        this.GS =                   serialNumber | 0b1100000000000000;
        this.EmergencyUserAlert =   serialNumber | 0b0010000000000000;
        this.Popup =                serialNumber | 0b0001000000000000;
        this.InformationPage =      serialNumber | 0b0000111111110000;
        this.updateNumber =         serialNumber | 0b0000000000001111;
    }

    public Boolean isDuplicate(int updateNumber){
        if( this.updateNumber == updateNumber) {
            return true;
        }
        else {
            return false;
        }
    }

    public Boolean isMoreInfo(){
        if( this.InformationPage != 0) {
            return true;
        }
        else {
            return false;
        }
    }

    public int getInformationPage() {
        return this.InformationPage;
    }

    public int getSerialNumber() {
        return this.serialNumber;
    }

    public int getEmergencyUserAlert() {
        return this.EmergencyUserAlert;
    }

    public int getPopup() {
        return this.Popup;
    }

    public int getUpdateNumber() {
        return this.updateNumber;
    }

    public int getGS() {
        return GS;
    }
}
