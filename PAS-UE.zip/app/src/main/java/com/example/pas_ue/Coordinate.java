package com.example.pas_ue;

public class Coordinate {
    double longitude;
    double latitude;


    public Coordinate(){

    }
/*
    //
    public void check(double longitude, double latitude){
        if(){

        }
    }
*/

    //사용자 GPS 정보 받아들임
    public void init(double longitude, double latitude){
        this.longitude = longitude;
        this.latitude = latitude;
    }



}
