package com.example.pas_ue;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.Serializable;
import java.util.Vector;

public class ShelterList implements Serializable {

    Boolean isAlert;
    Vector<Integer> shelterNumbers;
    Vector<Shelter> shelterVector;

    public ShelterList(){
        this.shelterNumbers = new Vector<Integer>();
        this.shelterVector = new Vector<Shelter>();
        this.isAlert = false;
    }

    public Vector<Integer> getShelterNumbers() {
        return this.shelterNumbers;
    }

    public void addNumber(int mod) {
        this.shelterNumbers.add(mod);
    }

    //쉘터문자의 쉘터들 각자 객체로 변환해서 저장
    public void extractJSON(String CB_Data){
        try {
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonObject= (JSONObject) jsonParser.parse( CB_Data );
            JSONArray jsonArray = (JSONArray)jsonObject.get("ShelterList");
            JSONObject object;
            String shelterFirstAddress = (String)jsonObject.get("shelterFirstAddress");
            String shelterLastAddress;
            String shelterName;
            String coordinate;

            for(int i = 0 ; i < jsonArray.length() ; i++){
                object = (JSONObject) jsonArray.get(i);
                shelterLastAddress = (String)object.get("shelterLastAddress");
                shelterName = (String)object.get("shelterName");
                coordinate = (String)object.get("coordinate");

                //쉘터정보 추출 후 객체 생성 및 추가
                Shelter shelter = new Shelter(shelterFirstAddress+shelterLastAddress,shelterName,coordinate);
                this.shelterVector.add(shelter);
            }

        } catch (ParseException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.i("addShelter","add shelter success");
    }
}
