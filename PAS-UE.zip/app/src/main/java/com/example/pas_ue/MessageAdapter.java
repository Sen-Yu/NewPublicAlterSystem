package com.example.pas_ue;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Vector;

public class MessageAdapter extends BaseAdapter {

    private TextView msgtextView;

    private ArrayList<MessageList_item_Activity> listViewList = new ArrayList<MessageList_item_Activity>();

    public MessageAdapter(){

    }

    @Override
    public int getCount() {
        return this.listViewList.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int itemId) {
        return itemId;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        int pos = i;
        Context context = viewGroup.getContext();

        if(view == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view =inflater.inflate(R.layout.activity_messagelist_item,viewGroup,false);
        }

        msgtextView = (TextView) view.findViewById(R.id.text_context);

        MessageList_item_Activity item = listViewList.get(i);

        msgtextView.setText(item.getMessageText());

        return view;
    }

    public void addItem(String msgContext){
        MessageList_item_Activity item = new MessageList_item_Activity();

        item.setmessageText(msgContext);

        listViewList.add(item);
    }
}
