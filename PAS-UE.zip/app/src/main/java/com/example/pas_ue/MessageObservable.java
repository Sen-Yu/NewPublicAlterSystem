package com.example.pas_ue;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class MessageObservable extends Observable implements Serializable {

    private ArrayList<MessageListActivity> observers;
    private Message message;
    private int classNum;


    public MessageObservable() {
        observers = new ArrayList<MessageListActivity>();
    }

    public void messageChanged() { // 새로운 소식이 들어왔다고 알려줌 (상태가 변했다고 알려주는 메소드)
        setChanged();
        this.notifyObservers(this.message,this.classNum);
    }

    public void notifyObservers(Message message, int classNum) {
        Log.d("MessageObservable","in notify");
        for(MessageListActivity observer: observers){
            observer.update(this.message,this.classNum);
            Log.d("MessageObservable","notify success");
        }
    }


    public void setMessage(Message message, int classNum) { // 새로운 소식이 들어오는 메소드
        Log.d("MessageObservable","message update");
        this.message = message;
        this.classNum = classNum;
        messageChanged();
    }

    public Message getMessage() {
        return this.message;
    }

    public int getClassNum(){
        return this.classNum;
    }

    public int getlistSize(){
        return this.observers.size();
    }

    public ArrayList<MessageListActivity> getObservers() {
        return observers;
    }
}
