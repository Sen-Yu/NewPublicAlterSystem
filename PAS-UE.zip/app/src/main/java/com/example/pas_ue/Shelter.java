package com.example.pas_ue;

import java.io.Serializable;

public class Shelter implements Serializable {

    String shelterAddress;
    String shelterName;
    double longitude;
    double latitude;

    double point;

    public Shelter(){

    }

    public Shelter(String shelterAddress,String shelterName ,String coordinate){
        this.shelterAddress = shelterAddress;
        this.shelterName = shelterName;
    }

    public Shelter(double longitude, double latitude){
        this.longitude = longitude;
        this.latitude = latitude;
    }

    public double cacluateDistance(double UE_longitude,double UE_latitude){
        return Math.pow(2,(UE_longitude - this.longitude)) + Math.pow(2,(UE_latitude - this.latitude)) ;

    }

    public void setshelterAddress(String shelterAddress) {
        this.shelterAddress = shelterAddress;
    }

}
