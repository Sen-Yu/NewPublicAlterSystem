package com.example.pas_ue;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

public class MessageList implements Serializable {

    //위급 재난 문자
    Vector<Message> class0;
    //긴급 재난 문자
    Vector<Message> class1;
    //안전 안내 문자
    Vector<Message> class2;
    Vector<Message> shelter;
    //그 외의 문자
    Vector<Message> MessageVector;
    //옵저버방식1
    MessageObservable messageObservable;
    Message message;
    int classNum;

    public MessageList(){
        this.class0 = new Vector<Message>();
        this.class1 = new Vector<Message>();
        this.class2 = new Vector<Message>();
        this.shelter = new Vector<Message>();
        this.MessageVector = new Vector<Message>();
        //옵저버방식1
        this.messageObservable = new MessageObservable();

    }

    public void setMessageVector(Vector<Message> messageVector) {
        MessageVector = messageVector;
    }
    public Vector<Message> getMessageVector() {
        return MessageVector;
    }
    //messageidentifier에 알맞은 클래스벡터 리턴
    public Vector<Message> checkClass(int messageIdentifier){
        if(messageIdentifier==4370){      //위급재난 문자
            Log.d("Tag","위급재난 문자 MSG");
            return this.class0;
        }else if(messageIdentifier==4371){// 긴급재난 문자
            Log.d("Tag","긴급재난 문자 MSG");
            return this.class1;
        }else if(messageIdentifier==4372){// 안전안내 문자
            Log.d("Tag","안전안내 문자 MSG");
            return this.class2;
        }else{  //그 외의 문자
            Log.d("Tag","기타 문자 MSG");
            return this.MessageVector;
        }

    }
    //클래스에 따른 메세지 벡터 리턴
    public Vector<Message> getClassVector(int num){
        if(num == 0){
            return this.class0;
        }
        else if(num == 1){
            return this.class1;
        }
        else if(num == 2){
            return this.class2;
        }
        else{
            return this.MessageVector;
        }
    }
    public int checkClassNum(int messageIdentifier){
        if(messageIdentifier==4370){      //위급재난 문자
            Log.d("Tag","위급재난 문자 MSG");
            return 0;
        }else if(messageIdentifier==4371){// 긴급재난 문자
            Log.d("Tag","긴급재난 문자 MSG");
            return 1;
        }else if(messageIdentifier==4372){// 안전안내 문자
            Log.d("Tag","안전안내 문자 MSG");
            return 2;
        }else{  //그 외의 문자
            Log.d("Tag","기타 문자 MSG");
            return -1;
        }
    }
    public Boolean isDuplicate(Vector<Message> vector ,Message msg){
        for(int i = 0 ; i < vector.size() ; i++){
            if(vector.get(i).getPureSerialNumber() == msg.getPureSerialNumber() &&
            vector.get(i).getMessageidentifier() == msg.getMessageidentifier()){
                return true;
            }
        }
        return false;
    }
    ////수신 메세지 해독 정보에 따른 실행
    public void classification(Vector<Message> vector,int classNum ,Message msg){
        Log.d("Tag","classification중");
        Message Inmessage;
        //수신받은 문자 판별
        int mod;
        //메세지벡터와 문자판별시 있던거
        int allmoad;
        //완전 첫문자
        if(vector.size() == 0){
            Log.d("Tag", "벡터의 최초 재난 문자");
            vector.add(msg);
            //---옵저버1---//
            this.messageObservable.setMessage(msg,classNum);
            //---옵저버2---//

        }
        else {
            for (int i = 0; i < vector.size(); i++) {
                Inmessage = vector.get(i);
                if (Inmessage.getMessageidentifier() == msg.getMessageidentifier()) {
                    // -1: 중복재난문자    0:최신 재난문자    1~:최신 쉘터정보
                    Log.d("Tag", Inmessage.getPureSerialNumber()+"vs"+ msg.getPureSerialNumber());
                    mod = compareSerialNumber(Inmessage.getPureSerialNumber(), msg.getPureSerialNumber());

                    //중복재난문자이기 때문에 폐기
                    if (mod == -1) {
                        //아무동작도안하고 탈출
                        Log.d("Tag", "중복 재난 문자");
                        break;
                    }
                    //최신 재난문자이기에 벡터에 문자추가
                    else if (mod == 0) {
                        //이전 메세지들 저장하기때문에 바로 추가 XXX
                        Log.d("Tag", "최신 재난 문자");
                        if( i == vector.size()-1){
                            vector.add(msg);
                            //---옵저버1---//
                            this.messageObservable.setMessage(msg,classNum);
                            //---옵저버2---//

                        }
                    }
                    //쉘터정보이기에 축적 및 중복판별
                    else if (mod > 0) {
                        //해당문자에 쉘터정보가 있는지 확인
                        if (Inmessage.hasShelterInfo()) {
                            //중복
                            if (Inmessage.is_DuplicateShelter(mod)) {
                                //아무동작도안하고 탈출
                                Log.d("Tag", "중복 쉘터 문자");
                                break;
                            }
                            //새로운 쉘터문자
                            else {
                                //쉘터문자 추가
                                Inmessage.addShelter(msg, mod);
                                Log.d("Tag", "새 쉘터 문자");
                            }
                        }
                        //쉘터정보가 없기에 새로 생성하고 정보추가
                        else {
                            //생성
                            Inmessage.createShelterInfo();

                            //추가(수정필요)
                            Inmessage.addShelter(msg, mod);
                            Log.d("Tag", "첫 쉘터 문자");
                        }
                    }
                    else{
                        Log.d("Tag", "잘못만들었따. ㄷㄷ");
                    }


                }

            }
        }
    }
    //confirm serialnumber에 대한 동일여부 비교
    //(받은 메세지의 시리얼넘버.메세지 목록내의 시리얼넘버)
    public int compareSerialNumber(int serialNumber, int recvSerialNumber){
        int GS              =   0b1100000000000000;
        int messageCode     =   0b0011111111110000;
        int Alert_POP       =   0b0011000000000000;
        int  moreInfonum    =   0b0000111111110000;
        int updateNumber    =   0b0000000000001111;

        int check1;
        int check2;

        check1 = serialNumber & GS;
        check2 = recvSerialNumber & GS;

        if( check1 == check2 ){
            check1 = serialNumber & Alert_POP;
            check2 = recvSerialNumber  & Alert_POP;

            //같은 클래스의 문자이다.
            if(check1 == check2) {
                check1 = serialNumber & updateNumber;
                check2 = recvSerialNumber & updateNumber;

                //해당 재난문자와 같은 업데이트번호이다.
                if (check1 == check2) {
                    check1 = serialNumber & moreInfonum;
                    check2 = recvSerialNumber & moreInfonum;

                    //해당 문자는 중복재난문자이다.
                    //00000000 == 00000000
                    if (check1 == check2){
                        return -1;
                    }
                    //해당문자는 쉘터정보 문자이다.
                    else{
                        //쉘터문자번호 리턴
                        //1~
                        return check2 - check1;
                    }
                }
                //해당 재난문자는 최신정보이다.
                else {

                    check1 = serialNumber & moreInfonum;
                    check2 = recvSerialNumber & moreInfonum;

                    return 0;

                }
            }
        }
        //아무것도 안속한는 경우
        //발생하면 안됨
        return -2;
    }

    public MessageObservable getMessageObservable() {
        return this.messageObservable;
    }


}
