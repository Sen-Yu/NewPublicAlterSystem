package com.example.pas_ue;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;

import static androidx.core.content.ContextCompat.getSystemService;

public class UserLocation {


    //final LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

    Location location;

    public UserLocation(){
        //location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
    }


    final LocationListener gpsLocationListener = new LocationListener() {
        public void onLocationChanged(Location location) {

            String provider = location.getProvider();
            double longitude = location.getLongitude();
            double latitude = location.getLatitude();
            double altitude = location.getAltitude();

        }

        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        public void onProviderEnabled(String provider) {
        }

        public void onProviderDisabled(String provider) {
        }
    };


}
