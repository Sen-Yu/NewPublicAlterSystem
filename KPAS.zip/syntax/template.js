var template = {
  html:function(title,body){
    return `
    <!doctype html>
    <html>
    <head>
      <title>PWS-CBE:${title}</title>
      <meta charset="utf-8" content="PWS-CBE">
    </head>
    <body>
      <h1><a href="/">PWS-CBE</a></h1>
      ${body}
      <a href="/Warning">Warning</a>
      <a href="/Shelter">Shelter</a>
    </body>
    </html>
    `},list:function(filelist){
      var list = `<ul>`;
      var i = 0;
      while( i < filelist.length){
        list = list + `<li><a href="/?id=${filelist[i]}">${filelist[i]}</a></li>`;
        i++;
      }
      list = list +`<ul>`;
      return list;
    },warning:function(){
      return`
      <form action="http://localhost:3000/Warning_process" method="post">
      <p>generator  <input type="text" name="Source" placeholder="ChangWon-city hall"></p>
      <p>disaster type  <input type="text" name="Calamity" placeholder="Earthquake,Tsunami,fine dust"></p>
      <p>disaster occurrence address <input type="text" name="WaringArea" placeholder="Uichang-gu, Changwon-si"></p>
      <p>disaster occurrence coordinate  <input type="text" name="WaringAreaCoordinate" placeholder="longitude,latitude"></p>
      <p>alter coverage(km)  <input type="text" name="waringCoverage" placeholder="10.000"></p>
      <p>warning mesaage context  <textarea name ="Context" placeholder="[ChangWon-city hall]"></textarea></p>
        <p><input type="submit"></p>
      </form>
      `;
    },shelter:function(warningList){
      return`
      <form action="http://localhost:3000/Shelter_process" method="post">
      <title>Shelter</title>
      ${this.selectWarning(warningList)}
      <p><input type="submit"></p>
      </form>
      `;
    },selectWarning:function(warningList){
      return`
      <form action="http://localhost:3000/Shelter/seletWarning_process" method="post">
      <title>SelectWarning</title>
      <meta charset="utf-8" content="PWS-CBE">
      <body>
        <select name = "warning_select" id = "warning_select" onchange = "select_value">
        <option value="-1">===select warning message===</option>
        ${this.printWarnings(warningList)}
      </body>
      <script>
       var select_value = function (select_obj){

       };
   </script>
      `;
    },printWarnings:function(warningList){
      var i = 0;
      var optionList ='';
      for(i ; i < warningList.length() ; i++){
        optionList += `<option value = ${i}>${warningList.getInfo(i)}</option>`
      }
      return optionList;
    },printInputShelters:function(num){
      var i = 0;
      var inputShelterList ='';
      for(i ; i < 3 ; i++){
        inputShelterList += `
        <p><input type="text" name="shelter_address${i}" placeholder="쉘터[${i}]구주소"></p>
        <p><input type="text" name="shelter_name${i}" placeholder="쉘터[${i}]이름"></p>
        <p><input type="text" name="shelterCoordinate${i}" placeholder="쉘터[${i}]좌표"></p>
        `
      }
      return inputShelterList;
    },alertError:function(context){
      return`
      <form action="http://localhost:3000/Shelter/seletWarning" method="post">
      <script language="javascript">
        function alerttest(){
          alert("${context}");
        }
        </script>
      `
    }
  };

module.exports = template;
