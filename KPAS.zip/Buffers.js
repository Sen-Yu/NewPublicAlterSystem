var WarningBuffer(source,calamity,warningArea,warningAreaCoordinates,context){
  this.source = source;
  this.calamity = calamity;
  this.warningArea = warningArea;
  this.warningAreaCoordinate = warningAreaCoordinates;
  this.context = context;

}
