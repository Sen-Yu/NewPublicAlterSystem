package com.company;

public class Confirm {

    int messageType;
    int messageidentifier;
    int serialNumber;
    int cause;





}
