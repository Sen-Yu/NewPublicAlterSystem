package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        new Server(6000);
        System.out.println("ready2");
    }
}
